package loops;

public class Test {
    public static void main(String[] args) {
        for (int i = 1; i < 20; i++) {

            if (i % 3 == 0) continue;
            System.out.println(i + " ");
        }

        boolean t = false;
        int a = 10;
        int b = 20;


        System.out.println("do vozvrata");



        System.out.println(a + b);
    }
}
