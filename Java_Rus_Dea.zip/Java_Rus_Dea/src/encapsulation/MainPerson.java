package encapsulation;

public class MainPerson {
    public static void main(String[] args) {
        Person person = new Person();

        person.setName("Suel");
        System.out.println(person.getName());
    }
}
