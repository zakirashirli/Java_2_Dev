package switchoperator;

public class CalendarMain {
    public static void main(String[] args) {
        int current_month = 9;

        switch (current_month){
            case 1:
                System.out.println("Yanvar");


            case 2:
                System.out.println("Fevral");


                case 3:
                System.out.println("Mart");


            case 4:
                System.out.println("Aprel");


            case 5:
                System.out.println("May");


            case 6:
                System.out.println("Yanvar");


            case 7:
                System.out.println("Yanvar");


            case 8:
                System.out.println("Yanvar");


            case 9:
                System.out.println("current month now september");
                break;

            case 10:
                System.out.println("Yanvar");


            case 11:
                System.out.println("Yanvar");


            case 12:
                System.out.println("Yanvar");

            default:
                System.out.println("No such a month in a year");
                break;

        }
    }
}
